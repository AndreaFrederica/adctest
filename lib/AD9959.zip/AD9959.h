#ifndef _AD9959_H_
#define _AD9959_H_
#include "ad9959sys.h"
#include "stdint.h"
#include <EasySPI.h>
#include <tools.h>
#include <EasyUART.h>


// AD9959管脚宏定义
// #define AD_CS PAout(6)
// #define AD_SCLK PBout(1)
// #define AD_UPDATE PBout(0)

// #define PS0 PAout(7)
// #define PS1 PAout(2)
// #define PS2 PBout(10)
// #define PS3 PCout(0)

// #define SDIO0 PAout(5)
// #define SDIO1 PAout(4)
// #define SDIO2 PAout(3)
// #define SDIO3 PAout(8)

// #define AD9959_PWR PAout(9)
// #define Reset PAout(10)

/*

*/

// 宏定义 (只保留和IO口初始化相关的宏定义)
// 宏定义 (更新AD9959的相关宏定义)
#define AD_CS_Pin GPIO_PIN_6
#define AD_CS_GPIO_Port GPIOE
#define AD_UPDATE_Pin GPIO_PIN_0
#define AD_UPDATE_GPIO_Port GPIOE

#define PS0_Pin GPIO_PIN_7
#define PS0_GPIO_Port GPIOE
#define PS1_Pin GPIO_PIN_2
#define PS1_GPIO_Port GPIOE
#define PS2_Pin GPIO_PIN_10
#define PS2_GPIO_Port GPIOE
#define PS3_Pin GPIO_PIN_12
#define PS3_GPIO_Port GPIOE

#define AD9959_PWR_Pin GPIO_PIN_9
#define AD9959_PWR_GPIO_Port GPIOE
#define Reset_Pin GPIO_PIN_11
#define Reset_GPIO_Port GPIOE

static void AD9959_MX_GPIO_Init(void);

// AD9959寄存器地址定义
#define CSR_ADD 0x00 // CSR 通道选择寄存器
#define FR1_ADD 0x01 // FR1 功能寄存器1
#define FR2_ADD 0x02 // FR2 功能寄存器2
#define CFR_ADD 0x03 // CFR 通道功能寄存器

#define CFTW0_ADD 0x04 // CTW0 通道频率转换字寄存器
#define CPOW0_ADD 0x05 // CPW0 通道相位转换字寄存器
#define ACR_ADD 0x06   // ACR 幅度控制寄存器

#define LSRR_ADD 0x07 // LSR 线性扫描斜率寄存器
#define RDW_ADD 0x08  // RDW 上升扫描增量寄存器
#define FDW_ADD 0x09  // FDW 下降扫描增量寄存器

#define PROFILE_ADDR_BASE 0x0A // Profile寄存器,配置文件寄存器起始地址

// CSR[7:4]通道选择启用位
#define CH0 0x10
#define CH1 0x20
#define CH2 0x40
#define CH3 0x80

// FR1[9:8] 调制电平选择位
#define LEVEL_MOD_2 0x00  // 2电平调制 2阶调制
#define LEVEL_MOD_4 0x01  // 4电平调制	4阶调制
#define LEVEL_MOD_8 0x02  // 8电平调制	8阶调制
#define LEVEL_MOD_16 0x03 // 16电平调制	16阶调制

// CFR[23:22]  幅频相位（AFP）选择位
#define DISABLE_Mod 0x00 // 00	调制已禁用
#define ASK 0x40         // 01	振幅调制，幅移键控
#define FSK 0x80         // 10	频率调制，频移键控
#define PSK 0xc0         // 11	相位调制，相移键控

// （CFR[14]）线性扫描启用 sweep enable
#define SWEEP_ENABLE 0x40  // 1	启用
#define SWEEP_DISABLE 0x00 // 0	不启用

void IntReset(void);              // AD9959复位
void IO_Update(void);             // AD9959更新数据
void Intserve(void);              // IO口电平状态初始化
void AD9959_Init(void);           // IO口初始化

/***********************AD9959基本寄存器操作函数*****************************************/
void AD9959_WriteData(uint8_t RegisterAddress,
                      uint8_t NumberofRegisters,
                      uint8_t* RegisterData); // 向AD9959写数据
void Write_CFTW0(uint32_t fre);   // 写CFTW0通道频率转换字寄存器
void Write_ACR(uint16_t Ampli);   // 写ACR通道幅度转换字寄存器
void Write_CPOW0(uint16_t Phase); // 写CPOW0通道相位转换字寄存器

void Write_LSRR(uint8_t rsrr, uint8_t fsrr); // 写LSRR线性扫描斜率寄存器
void Write_RDW(uint32_t r_delta);            // 写RDW上升增量寄存器
void Write_FDW(uint32_t f_delta);            // 写FDW下降增量寄存器

void Write_Profile_Fre(uint8_t profile, uint32_t data); // 写Profile寄存器,频率
void Write_Profile_Ampli(uint8_t profile,
                         uint16_t data); // 写Profile寄存器,幅度
void Write_Profile_Phase(uint8_t profile,
                         uint16_t data); // 写Profile寄存器,相位
/********************************************************************************************/

/*****************************点频操作函数***********************************/
void AD9959_Set_Fre(uint8_t Channel, uint32_t Freq);    // 写频率
void AD9959_Set_Amp(uint8_t Channel, uint16_t Ampli);   // 写幅度
void AD9959_Set_Phase(uint8_t Channel, uint16_t Phase); // 写相位
/****************************************************************************/

/*****************************调制操作函数  ***********************************/
void AD9959_Modulation_Init(uint8_t Channel,
                            uint8_t Modulation,
                            uint8_t Sweep_en,
                            uint8_t Nlevel); // 设置各个通道的调制模式。
void AD9959_SetFSK(uint8_t Channel,
                   uint32_t* data,
                   uint16_t Phase); // 设置FSK调制的参数
void AD9959_SetASK(uint8_t Channel,
                   uint16_t* data,
                   uint32_t fre,
                   uint16_t Phase); // 设置ASK调制的参数
void AD9959_SetPSK(uint8_t Channel,
                   uint16_t* data,
                   uint32_t Freq); // 设置PSK调制的参数

void AD9959_SetFre_Sweep(uint8_t Channel,
                         uint32_t s_data,
                         uint32_t e_data,
                         uint32_t r_delta,
                         uint32_t f_delta,
                         uint8_t rsrr,
                         uint8_t fsrr,
                         uint16_t Ampli,
                         uint16_t Phase); // 设置线性扫频的参数
void AD9959_SetAmp_Sweep(uint8_t Channel,
                         uint32_t s_Ampli,
                         uint16_t e_Ampli,
                         uint32_t r_delta,
                         uint32_t f_delta,
                         uint8_t rsrr,
                         uint8_t fsrr,
                         uint32_t fre,
                         uint16_t Phase); // 设置线性扫幅的参数
void AD9959_SetPhase_Sweep(uint8_t Channel,
                           uint16_t s_data,
                           uint16_t e_data,
                           uint16_t r_delta,
                           uint16_t f_delta,
                           uint8_t rsrr,
                           uint8_t fsrr,
                           uint32_t fre,
                           uint16_t Ampli); // 设置线性扫相的参数
/********************************************************************************************/




#define AD_SCK  GPIO_PIN_13 // SPI SCK 引脚
#define AD_SCK_GPIO_PORT GPIOB // SPI SCK GPIO 端口

#define SDIO0 GPIO_PIN_15 // SPI MOSI 引脚
#define SDIO0_GPIO_PORT GPIOB // SPI MOSI GPIO 端口

#define AD_CS GPIO_PIN_6  // SPI CS 引脚
#define AD_CS_GPIO_PORT GPIOE // SPI CS GPIO 端口

// 函数声明
void SoftSPI_GPIO_Init(void);








#endif // AD9959_H
